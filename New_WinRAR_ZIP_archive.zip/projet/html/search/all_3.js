var searchData=
[
  ['data_2ec_12',['data.c',['../data_8c.html',1,'']]],
  ['data_2eh_13',['data.h',['../data_8h.html',1,'']]],
  ['depasse_14',['depasse',['../data_8c.html#acd08f176ec86e02c69ea2f0524508c4e',1,'depasse(sprite_t *sprite):&#160;data.c'],['../data_8h.html#acd08f176ec86e02c69ea2f0524508c4e',1,'depasse(sprite_t *sprite):&#160;data.c']]]
];
