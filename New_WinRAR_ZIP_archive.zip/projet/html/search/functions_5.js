var searchData=
[
  ['load_5fimage_82',['load_image',['../sdl2-light_8c.html#a85a3dc2aec2bf7ee942b5761ed9e4b35',1,'load_image(const char path[], SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a85a3dc2aec2bf7ee942b5761ed9e4b35',1,'load_image(const char path[], SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
