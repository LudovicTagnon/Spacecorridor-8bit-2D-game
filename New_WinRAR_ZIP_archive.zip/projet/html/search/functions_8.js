var searchData=
[
  ['refresh_5fgraphics_86',['refresh_graphics',['../graphics_8c.html#a7f1255bcd2442cbb25e78a5c1ef06df1',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, resources_t *textures):&#160;graphics.c'],['../graphics_8h.html#a7f1255bcd2442cbb25e78a5c1ef06df1',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, resources_t *textures):&#160;graphics.c']]]
];
