var searchData=
[
  ['refresh_5fgraphics_34',['refresh_graphics',['../graphics_8c.html#a7f1255bcd2442cbb25e78a5c1ef06df1',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, resources_t *textures):&#160;graphics.c'],['../graphics_8h.html#a7f1255bcd2442cbb25e78a5c1ef06df1',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, resources_t *textures):&#160;graphics.c']]],
  ['resources_5fs_35',['resources_s',['../structresources__s.html',1,'']]],
  ['resources_5ft_36',['resources_t',['../graphics_8h.html#a44d2bd8dccad474d265e4696b1685b06',1,'graphics.h']]]
];
