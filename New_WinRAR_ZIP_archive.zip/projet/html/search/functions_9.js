var searchData=
[
  ['sprites_5fcollide_87',['sprites_collide',['../data_8c.html#aa35f099a7e2fcb62d60f44d7a061f151',1,'sprites_collide(sprite_t *sp1, sprite_t *sp2):&#160;data.c'],['../data_8h.html#aa35f099a7e2fcb62d60f44d7a061f151',1,'sprites_collide(sprite_t *sp1, sprite_t *sp2):&#160;data.c']]]
];
