var searchData=
[
  ['resources_5fs_48',['resources_s',['../structresources__s.html',1,'']]]
];
