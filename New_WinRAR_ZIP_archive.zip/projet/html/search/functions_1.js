var searchData=
[
  ['clean_64',['clean',['../graphics_8c.html#a95bd4a8c043d70f47cd9e35d824f79db',1,'clean(SDL_Window *window, SDL_Renderer *renderer, resources_t *textures, world_t *world):&#160;graphics.c'],['../graphics_8h.html#a95bd4a8c043d70f47cd9e35d824f79db',1,'clean(SDL_Window *window, SDL_Renderer *renderer, resources_t *textures, world_t *world):&#160;graphics.c']]],
  ['clean_5fdata_65',['clean_data',['../data_8c.html#abcbee1dbb5697f9d0de3f737f9c7aafe',1,'clean_data(world_t *world):&#160;data.c'],['../data_8h.html#abcbee1dbb5697f9d0de3f737f9c7aafe',1,'clean_data(world_t *world):&#160;data.c']]],
  ['clean_5fsdl_66',['clean_sdl',['../sdl2-light_8c.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c']]],
  ['clean_5ftexture_67',['clean_texture',['../sdl2-light_8c.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c']]],
  ['clean_5ftextures_68',['clean_textures',['../graphics_8c.html#a9ffe45d90c05c192d194cbb80ae7db32',1,'clean_textures(resources_t *textures):&#160;graphics.c'],['../graphics_8h.html#a9ffe45d90c05c192d194cbb80ae7db32',1,'clean_textures(resources_t *textures):&#160;graphics.c']]],
  ['clear_5frenderer_69',['clear_renderer',['../sdl2-light_8c.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
