var searchData=
[
  ['sprite_5ft_83',['sprite_t',['../data_8h.html#a5371414b10358aeda7c6bcec8196342f',1,'data.h']]]
];
