var searchData=
[
  ['refresh_5fgraphics_77',['refresh_graphics',['../graphics_8c.html#ad463e9558ab20ad44fa6299593f251bc',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, textures_t *textures):&#160;graphics.c'],['../graphics_8h.html#ad463e9558ab20ad44fa6299593f251bc',1,'refresh_graphics(SDL_Renderer *renderer, world_t *world, textures_t *textures):&#160;graphics.c']]]
];
