var searchData=
[
  ['sdl2_2dlight_2ec_51',['sdl2-light.c',['../sdl2-light_8c.html',1,'']]],
  ['sdl2_2dlight_2eh_52',['sdl2-light.h',['../sdl2-light_8h.html',1,'']]]
];
