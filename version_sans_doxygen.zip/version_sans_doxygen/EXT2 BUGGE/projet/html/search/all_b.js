var searchData=
[
  ['sdl2_2dlight_2ec_37',['sdl2-light.c',['../sdl2-light_8c.html',1,'']]],
  ['sdl2_2dlight_2eh_38',['sdl2-light.h',['../sdl2-light_8h.html',1,'']]],
  ['sprite_5fs_39',['sprite_s',['../structsprite__s.html',1,'']]],
  ['sprite_5ft_40',['sprite_t',['../data_8h.html#a5371414b10358aeda7c6bcec8196342f',1,'data.h']]],
  ['sprites_5fcollide_41',['sprites_collide',['../data_8c.html#aa35f099a7e2fcb62d60f44d7a061f151',1,'sprites_collide(sprite_t *sp1, sprite_t *sp2):&#160;data.c'],['../data_8h.html#aa35f099a7e2fcb62d60f44d7a061f151',1,'sprites_collide(sprite_t *sp1, sprite_t *sp2):&#160;data.c']]]
];
