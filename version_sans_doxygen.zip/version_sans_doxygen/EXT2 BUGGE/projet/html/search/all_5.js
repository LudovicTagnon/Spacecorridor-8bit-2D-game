var searchData=
[
  ['handle_5fevents_18',['handle_events',['../graphics_8c.html#a947b9f8960b2202788f43c71fbaa9d67',1,'handle_events(SDL_Event *event, world_t *world):&#160;graphics.c'],['../graphics_8h.html#a947b9f8960b2202788f43c71fbaa9d67',1,'handle_events(SDL_Event *event, world_t *world):&#160;graphics.c']]],
  ['handle_5fsprites_5fcollision_19',['handle_sprites_collision',['../data_8c.html#a62436fada5d6be9e84b36357a306d38c',1,'handle_sprites_collision(world_t *world, sprite_t *sp1, sprite_t *sp2):&#160;data.c'],['../data_8h.html#a62436fada5d6be9e84b36357a306d38c',1,'handle_sprites_collision(world_t *world, sprite_t *sp1, sprite_t *sp2):&#160;data.c']]],
  ['handle_5fwall_20',['handle_wall',['../graphics_8c.html#a16e904e4a8ed1ae9cb15a65941d15788',1,'handle_wall(SDL_Renderer *renderer, resources_t *textures, sprite_t *mur):&#160;graphics.c'],['../graphics_8h.html#a16e904e4a8ed1ae9cb15a65941d15788',1,'handle_wall(SDL_Renderer *renderer, resources_t *textures, sprite_t *mur):&#160;graphics.c']]]
];
