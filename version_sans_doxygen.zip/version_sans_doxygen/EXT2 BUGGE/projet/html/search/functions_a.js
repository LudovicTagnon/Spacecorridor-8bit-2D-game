var searchData=
[
  ['update_5fdata_88',['update_data',['../data_8c.html#a6c91f82a5ece8b14628159353390adf4',1,'update_data(world_t *world):&#160;data.c'],['../data_8h.html#a6c91f82a5ece8b14628159353390adf4',1,'update_data(world_t *world):&#160;data.c']]],
  ['update_5fscreen_89',['update_screen',['../sdl2-light_8c.html#adaf353d9ae01b52dd37cd0adf2d5c9ee',1,'update_screen(SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#adaf353d9ae01b52dd37cd0adf2d5c9ee',1,'update_screen(SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
