var searchData=
[
  ['world_5fs_45',['world_s',['../structworld__s.html',1,'']]],
  ['world_5ft_46',['world_t',['../data_8h.html#ad55869c5e54f717062ec699d20fa8886',1,'data.h']]]
];
