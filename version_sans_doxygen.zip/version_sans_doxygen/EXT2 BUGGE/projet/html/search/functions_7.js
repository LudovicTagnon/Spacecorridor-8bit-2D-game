var searchData=
[
  ['pause_84',['pause',['../sdl2-light_8c.html#a381e2d58c3d6a1f0fd8129bcc4726804',1,'pause(int time):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a381e2d58c3d6a1f0fd8129bcc4726804',1,'pause(int time):&#160;sdl2-light.c']]],
  ['print_5fsprite_85',['print_sprite',['../data_8c.html#a242b29f702d42f06f3cdf3843ee7f930',1,'print_sprite(sprite_t *sprite):&#160;data.c'],['../data_8h.html#a242b29f702d42f06f3cdf3843ee7f930',1,'print_sprite(sprite_t *sprite):&#160;data.c']]]
];
