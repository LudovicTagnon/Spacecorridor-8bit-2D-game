var searchData=
[
  ['apply_5fbackground_0',['apply_background',['../graphics_8c.html#aea7db68b68a4dffee7ecefff565f988f',1,'apply_background(SDL_Renderer *renderer, SDL_Texture *texture):&#160;graphics.c'],['../graphics_8h.html#aea7db68b68a4dffee7ecefff565f988f',1,'apply_background(SDL_Renderer *renderer, SDL_Texture *texture):&#160;graphics.c']]],
  ['apply_5fsprite_1',['apply_sprite',['../graphics_8c.html#a1d3be1f25017a0acd88a72bafbb70730',1,'apply_sprite(SDL_Renderer *renderer, SDL_Texture *texture, sprite_t *sprite):&#160;graphics.c'],['../graphics_8h.html#a1d3be1f25017a0acd88a72bafbb70730',1,'apply_sprite(SDL_Renderer *renderer, SDL_Texture *texture, sprite_t *sprite):&#160;graphics.c']]],
  ['apply_5ftexture_2',['apply_texture',['../sdl2-light_8c.html#aa94de38ff23c16e13439cbe9cea15256',1,'apply_texture(SDL_Texture *texture, SDL_Renderer *renderer, int x, int y):&#160;sdl2-light.c'],['../sdl2-light_8h.html#aa94de38ff23c16e13439cbe9cea15256',1,'apply_texture(SDL_Texture *texture, SDL_Renderer *renderer, int x, int y):&#160;sdl2-light.c']]]
];
