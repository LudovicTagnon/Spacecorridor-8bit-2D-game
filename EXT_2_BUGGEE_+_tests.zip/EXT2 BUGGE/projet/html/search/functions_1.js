var searchData=
[
  ['clean_57',['clean',['../graphics_8c.html#a7f417770b38ecfb6688b0726fd34dd92',1,'clean(SDL_Window *window, SDL_Renderer *renderer, textures_t *textures, world_t *world):&#160;graphics.c'],['../graphics_8h.html#a7f417770b38ecfb6688b0726fd34dd92',1,'clean(SDL_Window *window, SDL_Renderer *renderer, textures_t *textures, world_t *world):&#160;graphics.c']]],
  ['clean_5fdata_58',['clean_data',['../data_8c.html#abcbee1dbb5697f9d0de3f737f9c7aafe',1,'clean_data(world_t *world):&#160;data.c'],['../data_8h.html#abcbee1dbb5697f9d0de3f737f9c7aafe',1,'clean_data(world_t *world):&#160;data.c']]],
  ['clean_5fsdl_59',['clean_sdl',['../sdl2-light_8c.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c']]],
  ['clean_5ftexture_60',['clean_texture',['../sdl2-light_8c.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c']]],
  ['clean_5ftextures_61',['clean_textures',['../graphics_8c.html#a47508a80056a626ded3e02f0690fa432',1,'clean_textures(textures_t *textures):&#160;graphics.c'],['../graphics_8h.html#a47508a80056a626ded3e02f0690fa432',1,'clean_textures(textures_t *textures):&#160;graphics.c']]],
  ['clear_5frenderer_62',['clear_renderer',['../sdl2-light_8c.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
