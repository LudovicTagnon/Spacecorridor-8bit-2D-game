var searchData=
[
  ['depasse_63',['depasse',['../data_8c.html#acd08f176ec86e02c69ea2f0524508c4e',1,'depasse(sprite_t *sprite):&#160;data.c'],['../data_8h.html#acd08f176ec86e02c69ea2f0524508c4e',1,'depasse(sprite_t *sprite):&#160;data.c']]]
];
